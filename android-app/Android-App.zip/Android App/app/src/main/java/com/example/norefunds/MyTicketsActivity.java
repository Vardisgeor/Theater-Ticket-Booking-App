// MyTicketsActivity.java
package com.example.norefunds;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MyTicketsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TicketAdapter ticketAdapter;
    private List<TicketItem> ticketList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_tickets);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = prefs.getString("loggedInUserEmail", "guest");

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(view -> finish());


        recyclerView = findViewById(R.id.recyclerViewTickets);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // TICKETS
        ticketList = new ArrayList<>();
        //ticketList.add(new TicketItem("Romeo & Juliet", "April 7", "18:00 PM", "A7", "Broadway Hall","0"));
        //ticketList.addAll(TicketItem.tickets);

        loadUserBookings(username);

        ticketAdapter = new TicketAdapter(ticketList);
        ticketAdapter = new TicketAdapter(ticketList);
        ticketAdapter.setOnCancelClickListener(position -> {
            new AlertDialog.Builder(this)
                    .setTitle("Cancel Ticket")
                    .setMessage("Are you sure you want to cancel this ticket?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        TicketItem ticket = ticketList.get(position);
                        String bookingId = ticket.getBookingId();
                        removeBookingById(username, bookingId);

                        ticketList.remove(position);
                        ticketAdapter.notifyItemRemoved(position);
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
        recyclerView.setAdapter(ticketAdapter);

        recyclerView.setAdapter(ticketAdapter);
    }
    private void loadUserBookings(String userName) {
        try {
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String jsonStr = prefs.getString(userName, "{}");
            JSONObject userData = new JSONObject(jsonStr);

            if (!userData.has("bookings")) return;

            JSONObject bookings = userData.getJSONObject("bookings");
            JSONArray bookingIds = bookings.names();

            if (bookingIds == null) return;

            for (int i = 0; i < bookingIds.length(); i++) {
                String bookingId = bookingIds.getString(i);
                JSONObject booking = bookings.getJSONObject(bookingId);

                String play = booking.getString("play");
                String hall = booking.getString("hall");
                String showtime = booking.getString("showtime");
                String tickets = booking.getString("num_tickets");

                JSONArray seatsJson = booking.getJSONArray("seats");
                StringBuilder seatsStr = new StringBuilder();
                for (int j = 0; j < seatsJson.length(); j++) {
                    seatsStr.append(seatsJson.getString(j));
                    if (j < seatsJson.length() - 1) seatsStr.append(", ");
                }

                TicketItem item = new TicketItem(play,"01/07/2025",showtime,seatsJson.toString(), hall, bookingId);

                ticketList.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void removeBookingById(String userName, String bookingId) {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String jsonStr = prefs.getString(userName, "{}");

        try {
            JSONObject userData = new JSONObject(jsonStr);

            if (userData.has("bookings")) {
                JSONObject bookings = userData.getJSONObject("bookings");

                if (bookings.has(bookingId)) {
                    bookings.remove(bookingId);
                    userData.put("bookings", bookings);

                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString(userName, userData.toString());
                    editor.apply();

                    Log.d("BookingRemove", "Booking with ID " + bookingId + " removed.");
                } else {
                    Log.w("BookingRemove", "Booking ID not found: " + bookingId);
                }
            } else {
                Log.w("BookingRemove", "No bookings found for user.");
            }
        } catch (JSONException e) {
            Log.e("BookingRemoveError", "Failed to remove booking: " + e.getMessage());
            e.printStackTrace();
        }
    }



}
