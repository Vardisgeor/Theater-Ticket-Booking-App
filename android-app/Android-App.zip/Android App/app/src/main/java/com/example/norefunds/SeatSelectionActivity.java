package com.example.norefunds;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SeatSelectionActivity extends AppCompatActivity {

    private RecyclerView rvSeats;
    private SeatAdapter adapter;
    private List<Seat> seatList;
    private int seatLimit = 1;  // Default in case parsing fails

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_selection);

        rvSeats = findViewById(R.id.rvSeats);
        Button btnDone = findViewById(R.id.btnDone);
        rvSeats.setLayoutManager(new GridLayoutManager(this, 8)); // 8 columns per row

        // Get reply message from intent
        String seatsText = getIntent().getStringExtra("seatsText");

        seatList = new ArrayList<>();

        Pattern pattern = Pattern.compile("Available seats:\\s*(.*?)\\s*Select\\s+(\\d+)\\s+seats", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher matcher = pattern.matcher(seatsText);

        if (matcher.find()) {
            String seatNumbers = matcher.group(1).trim();
            seatLimit = Integer.parseInt(matcher.group(2).trim());
            Log.d("SeatParser", seatNumbers);
            Set<String> reservedSeats = getAllReservedSeats();


            String[] numbers = seatNumbers.split(",");
            for (String seatId : numbers) {
                seatId = seatId.trim();
                if (!seatId.isEmpty()) {
                    boolean isAvailable = !reservedSeats.contains(seatId);
                    Seat seat = new Seat(seatId, isAvailable);
                    seatList.add(seat);
                }
            }


            for (Seat seat : seatList) {
                Log.d("SeatParser", "Parsed seat: " + seat.getNumber());
            }

        }
        adapter = new SeatAdapter(this, seatList, seatLimit);
        rvSeats.setAdapter(adapter);

        btnDone.setOnClickListener(v -> {
            List<String> selected = new ArrayList<>();
            for (Seat s : seatList) {
                if (s.isSelected()) selected.add(s.getNumber());
            }

            if (selected.size() != seatLimit) {
                Toast.makeText(this, "Please select exactly " + seatLimit + " seats", Toast.LENGTH_SHORT).show();
            } else {
                String selectedSeatsStr = String.join(",", selected);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("selectedSeats", selectedSeatsStr);  // Sending as plain comma-separated string
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    private Set<String> getAllReservedSeats() {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        Map<String, ?> allUsers = prefs.getAll();
        Set<String> reservedSeats = new HashSet<>();

        for (Map.Entry<String, ?> entry : allUsers.entrySet()) {
            String userKey = entry.getKey();
            Object value = entry.getValue();

            if (!(value instanceof String)) {
                Log.w("ReservedSeatParser", "Skipping non-String value for key: " + userKey);
                continue;
            }

            try {
                JSONObject userData = new JSONObject((String) value);

                if (userData.has("bookings")) {
                    JSONObject bookings = userData.getJSONObject("bookings");
                    Iterator<String> keys = bookings.keys();
                    while (keys.hasNext()) {
                        String bookingId = keys.next();
                        JSONObject booking = bookings.getJSONObject(bookingId);

                        if (booking.has("seats")) {
                            // Parse seats as JSON array, not as simple string!
                            String seatsStr = booking.getString("seats");
                            // seatsStr is probably like '["A5"]' or '["A1"]', i.e., JSON array string

                            JSONArray seatsArray = new JSONArray(seatsStr);
                            for (int i = 0; i < seatsArray.length(); i++) {
                                String seat = seatsArray.getString(i);
                                reservedSeats.add(seat.trim());
                            }
                        }
                    }
                }

            } catch (JSONException e) {
                Log.e("ReservedSeatParser", "Failed to parse user data for " + userKey, e);
            }
        }

        Log.d("ReservedSeatParser", "All reserved seats: " + reservedSeats);
        return reservedSeats;
    }



}
