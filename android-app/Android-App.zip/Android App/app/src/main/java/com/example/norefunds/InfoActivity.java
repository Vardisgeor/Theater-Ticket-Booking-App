package com.example.norefunds;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.net.Uri;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class InfoActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(view -> finish());

        FrameLayout btnContactUs         = findViewById(R.id.btnContactUs);
        FrameLayout btnMoreAboutUs       = findViewById(R.id.btnMoreAboutUs);
        FrameLayout btnRateUs            = findViewById(R.id.btnRateUs);
        FrameLayout btnTerms   = findViewById(R.id.btnTermsConditions);

        // LISTENERS
        btnContactUs.setOnClickListener(v -> {
            startActivity(new Intent(InfoActivity.this, ContactUsActivity.class));
        });

        btnRateUs.setOnClickListener(v -> {
            startActivity(new Intent(InfoActivity.this, RateUsActivity.class));
        });

        btnTerms.setOnClickListener(v -> {
            startActivity(new Intent(InfoActivity.this, TermsConditionsActivity.class));
        });




        btnMoreAboutUs.setOnClickListener(v -> {
            Uri theatreUri = Uri.parse("https://aefestival.gr/");
            Intent webIntent = new Intent(Intent.ACTION_VIEW, theatreUri);
            startActivity(webIntent);
        });


    }
}
