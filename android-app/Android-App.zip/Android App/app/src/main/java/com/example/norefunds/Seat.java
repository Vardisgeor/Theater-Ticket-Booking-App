package com.example.norefunds;

public class Seat {
    private String number;
    private boolean available;
    private boolean selected;

    public Seat(String number, boolean available) {
        this.number = number;
        this.available = available;
        this.selected = false;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}

