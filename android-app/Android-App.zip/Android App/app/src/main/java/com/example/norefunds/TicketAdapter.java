package com.example.norefunds;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.text.TextUtils;


public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.TicketViewHolder> {

    private List<TicketItem> ticketList;
    private OnCancelClickListener cancelClickListener;

    public interface OnCancelClickListener {
        void onCancelClick(int position);
    }

    public void setOnCancelClickListener(OnCancelClickListener listener) {
        this.cancelClickListener = listener;
    }

    public TicketAdapter(List<TicketItem> ticketList) {
        this.ticketList = ticketList;
    }

    @NonNull
    @Override
    public TicketViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ticket_item, parent, false);
        return new TicketViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TicketViewHolder holder, int position) {
        TicketItem ticket = ticketList.get(position);
        holder.tvPlayName.setText(ticket.getPlayName());

        Object seatObj = ticket.getSeat();

        if (seatObj instanceof List) {
            // Handle list of seats
            @SuppressWarnings("unchecked")
            List<String> seats = (List<String>) seatObj;

            if (seats != null && !seats.isEmpty()) {
                holder.tvSeat.setText(TextUtils.join(", ", seats));
            } else {
                holder.tvSeat.setText("No seat");
            }

        } else if (seatObj instanceof String) {
            // Handle single seat
            String seat = (String) seatObj;
            if (seat != null && !seat.trim().isEmpty()) {
                holder.tvSeat.setText(seat.trim());
            } else {
                holder.tvSeat.setText("No seat");
            }

        } else {
            // Unknown or null
            holder.tvSeat.setText("No seat");
        }

        holder.tvTime.setText(ticket.getTime());
        holder.tvID.setText(ticket.getBookingId());


        holder.btnCancelTicket.setOnClickListener(view -> {
            if (cancelClickListener != null) {
                cancelClickListener.onCancelClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return ticketList.size();
    }

    private void cancelTicket(int position) {
        ticketList.remove(position);
        notifyItemRemoved(position);
        // Optionally notifyItemRangeChanged(position, ticketList.size());
    }


    public static class TicketViewHolder extends RecyclerView.ViewHolder {
        public View btnCancelTicket;
        TextView tvPlayName, tvDate, tvSeat, tvLocation, tvID, tvTime;

        public TicketViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPlayName = itemView.findViewById(R.id.tvPlayName);
            tvSeat = itemView.findViewById(R.id.tvSeat);
            tvID = itemView.findViewById(R.id.tvId);
            tvTime = itemView.findViewById(R.id.tvTime);
            btnCancelTicket = itemView.findViewById(R.id.btnCancelTicket);
        }
    }

}

