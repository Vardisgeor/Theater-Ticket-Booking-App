package com.example.norefunds;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RateUsActivity extends AppCompatActivity {
    private ImageButton[] stars;
    private int currentRating = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_us);

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(view -> finish());

        stars = new ImageButton[] {
                findViewById(R.id.star1),
                findViewById(R.id.star2),
                findViewById(R.id.star3),
                findViewById(R.id.star4),
                findViewById(R.id.star5)
        };

        // LISTENERS
        for (int i = 0; i < stars.length; i++) {
            final int index = i + 1;
            stars[i].setOnClickListener(v -> updateStars(index));
        }

        // SUBMIT
        Button btnSubmit = findViewById(R.id.btnSubmitRating);
        btnSubmit.setOnClickListener(v -> {
            if (currentRating == 0) {
                Toast.makeText(this, "Please select a rating", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Thanks for the rating!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateStars(int rating) {
        currentRating = rating;
        for (int i = 0; i < stars.length; i++) {
            if (i < rating) {
                stars[i].setImageResource(R.drawable.star_filled);
            } else {
                stars[i].setImageResource(R.drawable.star_empty);
            }
        }
    }
}
