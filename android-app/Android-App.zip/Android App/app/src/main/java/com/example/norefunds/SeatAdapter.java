package com.example.norefunds;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SeatAdapter extends RecyclerView.Adapter<SeatAdapter.SeatViewHolder> {

    private final List<Seat> seats;
    private final Context ctx;
    // Colors
    private final int COLOR_AVAILABLE = Color.parseColor("#4CAF50"); // green
    private final int COLOR_UNAVAILABLE = Color.parseColor("#F44336"); // red
    private final int COLOR_SELECTED = Color.parseColor("#2196F3"); // blue

    private final int seatLimit;
    private int selectedCount = 0;

    public SeatAdapter(Context context, List<Seat> seats, int seatLimit) {
        this.ctx = context;
        this.seats = seats;
        this.seatLimit = seatLimit;
    }

    @NonNull
    @Override
    public SeatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SeatViewHolder(
                (androidx.appcompat.widget.AppCompatToggleButton)
                        LayoutInflater.from(ctx).inflate(R.layout.seat_item, parent, false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull SeatViewHolder holder, int position) {
        Seat seat = seats.get(position);
        holder.toggle.setOnCheckedChangeListener(null);

        holder.toggle.setChecked(seat.isSelected());
        holder.toggle.setEnabled(seat.isAvailable());
        holder.toggle.setText(seat.getNumber());
        Log.d("SeatDebug", seat.getNumber() + " isAvailable: " + seat.isAvailable() + " isSelected: " + seat.isSelected());

        if (!seat.isAvailable()) {
            holder.toggle.setChecked(false);
            holder.toggle.setEnabled(false);
            holder.toggle.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(COLOR_UNAVAILABLE));
        } else if (seat.isSelected()) {
            holder.toggle.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(COLOR_SELECTED));
        } else {
            holder.toggle.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(COLOR_AVAILABLE));
        }


        holder.toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!seat.isAvailable()) return;

            if (isChecked) {
                if (selectedCount >= seatLimit) {
                    buttonView.setChecked(false); // undo
                    return;
                }
                seat.setSelected(true);
                selectedCount++;
                buttonView.setBackgroundTintList(ColorStateList.valueOf(COLOR_SELECTED));
            } else {
                seat.setSelected(false);
                selectedCount--;
                buttonView.setBackgroundTintList(ColorStateList.valueOf(COLOR_AVAILABLE));
            }
        });

    }

    @Override
    public int getItemCount() {
        return seats.size();
    }

    static class SeatViewHolder extends RecyclerView.ViewHolder {
        androidx.appcompat.widget.AppCompatToggleButton toggle;
        SeatViewHolder(@NonNull androidx.appcompat.widget.AppCompatToggleButton view) {
            super(view);
            toggle = view;
        }
    }


}
