package com.example.norefunds;

import java.util.ArrayList;

public class TicketItem {
    private String play, date, time, seat, location, bookingId;
    private double price;
    //public static ArrayList<TicketItem> tickets;

    public TicketItem(String playName, String date, String time, String seat, String location, String bookingId) {
        this.play = playName;
        this.date = date;
        this.time = time;
        this.seat = seat;
        this.location = location;
        this.bookingId = bookingId;

    }
    public String getBookingId() {
        return bookingId;
    }
    public String getPlayName() { return play; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getSeat() { return seat; }
    public String getLocation() { return location; }
}

