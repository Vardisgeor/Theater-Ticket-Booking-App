package com.example.norefunds;

import android.content.Intent;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class PaymentActivity extends AppCompatActivity {

    // Card Preview Components
    private CardView cardPreview;
    private TextView tvCardNumber;
    private TextView tvCardHolder;
    private TextView tvExpiry;

    // Input Fields
    private TextInputLayout cardNumberLayout;
    private TextInputEditText etCardNumber;
    private TextInputLayout expiryDateLayout;
    private TextInputEditText etExpiryDate;
    private TextInputLayout cvvLayout;
    private TextInputEditText etCVV;
    private TextInputLayout cardHolderLayout;
    private TextInputEditText etCardHolder;

    // Button
    private MaterialButton payButton;

    // Progress
    private ProgressBar progressBar;
    private ImageView successIcon;

    private boolean isCardNumberValid = false;
    private boolean isExpiryValid = false;
    private boolean isCvvValid = false;
    private boolean isNameValid = false;

    // Add these to the top of your class
    private static final int CARD_NUMBER_LENGTH = 16;
    private static final int CVV_MIN_LENGTH = 3;
    private static final int CVV_MAX_LENGTH = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        initializeViews();
        setupTextWatchers();
        setupButtonActions();
        setupAnimations();
    }

    private void initializeViews() {
        // Card Preview
        cardPreview = findViewById(R.id.cardPreview);
        tvCardNumber = findViewById(R.id.tvCardNumber);
        tvCardHolder = findViewById(R.id.tvCardHolder);
        tvExpiry = findViewById(R.id.tvExpiry);

        // Input Fields
        cardNumberLayout = findViewById(R.id.cardNumberLayout);
        etCardNumber = findViewById(R.id.etCardNumber);
        expiryDateLayout = findViewById(R.id.expiryDateLayout);
        etExpiryDate = findViewById(R.id.etExpiryDate);
        cvvLayout = findViewById(R.id.cvvLayout);
        etCVV = findViewById(R.id.etCVV);
        cardHolderLayout = findViewById(R.id.cardHolderLayout);
        etCardHolder = findViewById(R.id.etCardHolder);

        // Button & Progress
        payButton = findViewById(R.id.payButton);
        progressBar = findViewById(R.id.progressBar);      // Add this
        successIcon = findViewById(R.id.successIcon);
    }

    private void setupTextWatchers() {
        etCardNumber.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                formatCardNumber(s);
                updateCardPreview(s.toString());
                validateCardNumber(s.toString());
            }
        });

        etExpiryDate.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                formatExpiryDate(s);
                validateExpiryDate(s.toString());
                updateExpiryPreview(s.toString());
            }
        });

        etCVV.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                validateCVV(s.toString());
            }
        });

        etCardHolder.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                validateName(s.toString());
                updateCardHolderPreview(s.toString());
            }
        });
    }


    private void updateCardPreview(String number) {
        tvCardNumber.setText(number.isEmpty() ? "•••• •••• •••• ••••" : number);
    }

    private void updateExpiryPreview(String expiry) {
        if (expiry.length() >= 2) {
            String month = expiry.substring(0, 2);
            String year = expiry.length() > 3 ? expiry.substring(3) : "";
            tvExpiry.setText((month + "/" + year).replace("//", "/"));
        } else {
            tvExpiry.setText("MM/YY");
        }
    }

    private void updateCardHolderPreview(String name) {
        tvCardHolder.setText(name.isEmpty() ? "CARD HOLDER" : name.toUpperCase());
    }

    private void setupButtonActions() {
        payButton.setOnClickListener(v -> {
            if (validateAllFields()) {
                processPayment();
            } else {
                showValidationErrors();
            }
        });

        cvvLayout.setEndIconOnClickListener(v ->
                showHelpDialog("CVV Help", "3-4 digit code on the back of your card"));
    }

    // Keep all other methods from previous implementation
    // (validateAllFields, showValidationErrors, processPayment, etc...)

    private void setupAnimations() {
        cardPreview.animate()
                .translationZ(dpToPx(8))
                .setDuration(500)
                .start();
    }

    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    private void formatCardNumber(Editable s) {
        String original = s.toString();
        String digitsOnly = original.replaceAll("\\D", ""); // remove all non-digits

        // Limit to max 16 digits (standard card number length)
        if (digitsOnly.length() > 16) {
            digitsOnly = digitsOnly.substring(0, 16);
        }

        // Insert spaces every 4 digits
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < digitsOnly.length(); i++) {
            if (i > 0 && i % 4 == 0) {
                formatted.append(" ");
            }
            formatted.append(digitsOnly.charAt(i));
        }

        // Only update if text has changed
        String formattedStr = formatted.toString();
        if (!formattedStr.equals(original)) {
            s.replace(0, s.length(), formattedStr);
        }
    }


    private void validateCardNumber(String number) {
        String cleanNumber = number.replaceAll(" ", "");
        isCardNumberValid = cleanNumber.length() == 16;
        cardNumberLayout.setError(isCardNumberValid ? null : "Invalid card number");
    }

    private void formatExpiryDate(Editable s) {
        if (s.length() == 2 && !s.toString().contains("/")) {
            s.append("/");
        }

    }


    private void validateExpiryDate(String date) {
        isExpiryValid = date.matches("^(0[1-9]|1[0-2])\\/([0-9]{2})$");
        expiryDateLayout.setError(isExpiryValid ? null : "Invalid expiry date");
    }

    private void validateCVV(String cvv) {
        isCvvValid = cvv.length() == 3 || cvv.length() == 4;
        cvvLayout.setError(isCvvValid ? null : "CVV must be 3-4 digits");
    }

    private void validateName(String name) {
        isNameValid = !name.trim().isEmpty();
        cardHolderLayout.setError(isNameValid ? null : "Please enter cardholder name");
    }

    private boolean validateAllFields() {
        return isCardNumberValid && isExpiryValid && isCvvValid && isNameValid;
    }

    private void processPayment() {
        // Disable button during processing
        payButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);

        // Simulate payment processing
        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            showSuccessAnimation();
            navigateToConfirmation();
        }, 2000);
    }

    private void showValidationErrors() {
        if (!isCardNumberValid) {
            cardNumberLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        }
        if (!isExpiryValid) {
            expiryDateLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        }
        if (!isCvvValid) {
            cvvLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        }
        if (!isNameValid) {
            cardHolderLayout.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        }

        Toast.makeText(this, "Please fix validation errors", Toast.LENGTH_SHORT).show();
    }

    private void showHelpDialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    // Add these helper methods
    private void showSuccessAnimation() {
        // Make sure the icon is visible
        successIcon.setVisibility(View.VISIBLE);

        // Clear any previous drawable
        successIcon.setImageDrawable(null);

        try {
            // Load the animated vector
            AnimatedVectorDrawableCompat avd = AnimatedVectorDrawableCompat.create(
                    this,
                    R.drawable.ic_secetion_anim
            );

            // Set the drawable
            successIcon.setImageDrawable(avd);

            // Start animation if loaded successfully
            if (avd != null) {
                avd.start();
            } else {
                // Fallback to static image if animation fails
                successIcon.setImageResource(R.drawable.ic_check_circle);
            }
        } catch (Exception e) {
            Log.e("Animation", "Error during animation", e);
            successIcon.setImageResource(R.drawable.ic_check_circle);
        }
    }

    private void navigateToConfirmation() {
        new Handler().postDelayed(() -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("paymentResult", "ok");
            setResult(RESULT_OK, resultIntent);
            finish(); // This returns to ChatbotActivity
        }, 1500);
    }

}