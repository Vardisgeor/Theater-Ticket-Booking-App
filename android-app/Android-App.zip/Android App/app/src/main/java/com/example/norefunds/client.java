package com.example.norefunds;

import android.os.AsyncTask;
import android.util.Log;

import okhttp3.*;
import org.json.JSONObject;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class client {
    private static final String TAG = "NetworkClient";
    private static final String NGROK_URL = "https://2aaa-35-234-55-143.ngrok-free.app/chat";

    public interface NetworkCallback {
        void onSuccess(String response);
        void onError(String error);
    }

    public static void sendMessage(String message, NetworkCallback callback) {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... params) {
                OkHttpClient client = new OkHttpClient.Builder()
                        .connectTimeout(10, TimeUnit.SECONDS)
                        .readTimeout(30, TimeUnit.SECONDS)
                        .build();

                MediaType JSON = MediaType.parse("application/json; charset=utf-8");
                RequestBody body = RequestBody.create(JSON, "{\"message\":\"" + params[0] + "\"}");

                Request request = new Request.Builder()
                        .url(NGROK_URL)
                        .post(body)
                        .addHeader("Content-Type", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    return response.body().string();
                } catch (Exception e) {
                    Log.e(TAG, "Error: " + e.getMessage());
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    callback.onSuccess(result);
                } else {
                    callback.onError("Request failed");
                }
            }
        }.execute(message);
    }
}