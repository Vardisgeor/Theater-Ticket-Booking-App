// MyTicketsActivity.java
package com.example.norefunds;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class ChatbotActivity extends AppCompatActivity {
    private RecyclerView chatRecyclerView;
    private TextView textView;
    private ActivityResultLauncher<Intent> seatSelectionLauncher, paymentLauncher;

    private EditText messageEditText;
    private Button sendButton, back , help;
    private View rootView;
    private ChatAdapter adapter;
    private List<String> messages = new ArrayList<>();

    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;
    private boolean isListening = false;

    private TextToSpeech textToSpeech;
    private boolean ttsEnabled = false;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String username = prefs.getString("loggedInUserEmail", "guest");

        Log.d("nameChat", "User name: " + username);

        ImageView btnBack = findViewById(R.id.backArrow);
        btnBack.setOnClickListener(view -> finish());

        //resetChatSession();
        // Initialize UI components
        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);

        // Set up RecyclerView
        adapter = new ChatAdapter();
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chatRecyclerView.setAdapter(adapter);

        // Show typing indicator
        ChatMessage typingMessage = new ChatMessage(ChatMessage.TYPE_TYPING, "");
        adapter.addMessage(typingMessage);
        chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);

        client.sendMessage("START", new client.NetworkCallback() {
            @Override
            public void onSuccess(String response) {
                runOnUiThread(() -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        String reply = json.getString("reply");

                        // Remove typing and add bot response
                        adapter.removeTyping();
                        ChatMessage botMessage = new ChatMessage(ChatMessage.TYPE_BOT, reply);
                        adapter.addMessage(botMessage);
                        chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);

                    } catch (JSONException e) {
                        handleError("Error parsing response");
                    }
                });
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    handleError("Connection error: " + error);
                });
            }
        });

        ImageView helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHelpDialog();
            }
        });



        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = messageEditText.getText().toString().trim();
                messages.add(message);
                if (!message.isEmpty()) {
                    // Add user's message
                    ChatMessage userMessage = new ChatMessage(ChatMessage.TYPE_USER, message);
                    adapter.addMessage(userMessage);
                    chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);
                    messageEditText.setText("");

                    // Show typing indicator
                    ChatMessage typingMessage = new ChatMessage(ChatMessage.TYPE_TYPING, "");
                    adapter.addMessage(typingMessage);
                    chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);


                    // Send message to server
                    client.sendMessage(message, new client.NetworkCallback() {
                        @Override
                        public void onSuccess(String response) {
                            runOnUiThread(() -> {

                                try {
                                    JSONObject json = new JSONObject(response);
                                    String reply = json.getString("reply");

                                    // Remove typing and add bot response
                                    adapter.removeTyping();
                                    ChatMessage botMessage = new ChatMessage(ChatMessage.TYPE_BOT, reply);

                                    Log.d("CCC", reply);

                                    if (reply.trim().toLowerCase().startsWith("available seats")) {
                                        Intent intent = new Intent(ChatbotActivity.this, SeatSelectionActivity.class);
                                        intent.putExtra("seatsText", reply);
                                        seatSelectionLauncher.launch(intent);

                                    } else if (reply.toLowerCase().contains("payment process")) {
                                        Intent intent = new Intent(ChatbotActivity.this, PaymentActivity.class);
                                        intent.putExtra("payment", reply);
                                        paymentLauncher.launch(intent);
                                    } else if(reply.trim().toLowerCase().startsWith("booked") || reply.replaceAll("^\\s+", "").toLowerCase().startsWith("your booking is")){
                                        Log.d("AAA", "Username: " + username + " | Reply: " + reply);
                                        addBookingFromText(username,reply);
                                        adapter.addMessage(botMessage);
                                        if (ttsEnabled) {
                                            textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                        }
                                    }else if (reply.trim().toLowerCase().matches("booking \\d+ for .*(?:canceled\\.|not found\\.)")) {
                                        Log.d("CancelFlow", "Reply indicates a cancellation intent");

                                        // Try to extract booking ID from the text
                                        Pattern pattern = Pattern.compile("Booking\\s+(\\d+)\\s+for\\s+([\\w.+-]+@[\\w.-]+)\\s+(canceled\\.|not found\\.)", Pattern.CASE_INSENSITIVE);
                                        Matcher matcher = pattern.matcher(reply);
                                        if (matcher.find()) {

                                            String bookingId = matcher.group(1);
                                            String email = matcher.group(2);

                                            removeBookingById(email, bookingId);

                                            Toast.makeText(ChatbotActivity.this, "Booking " + bookingId + " cancelled.", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(ChatbotActivity.this, "Oops, something went wrong your booking is still valib.\n Try again later...", Toast.LENGTH_SHORT).show();
                                        }

                                        adapter.addMessage(botMessage);
                                        if (ttsEnabled) {
                                            textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                        }
                                    } else{
                                        Log.d("BBB", "Username: " + username + " | Reply: " + reply);
                                        adapter.addMessage(botMessage);
                                        if (ttsEnabled) {
                                            textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                        }
                                    }


                                    // Scroll to the latest message
                                    chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);

                                } catch (JSONException e) {
                                    handleError("Error parsing response");
                                }
                            });
                        }

                        @Override
                        public void onError(String error) {
                            runOnUiThread(() -> {
                                handleError("Connection error: " + error);
                            });
                        }
                    });
                }
            }

        });

        paymentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String paymentResult = data.getStringExtra("paymentResult");
                            if ("ok".equals(paymentResult)) {
                                ChatMessage message = new ChatMessage(ChatMessage.TYPE_USER, "ok");
                                adapter.addMessage(message);

                                client.sendMessage(message.getContent(), new client.NetworkCallback() {
                                    @Override
                                    public void onSuccess(String response) {
                                        runOnUiThread(() -> {

                                            try {
                                                JSONObject json = new JSONObject(response);
                                                String reply = json.getString("reply");

                                                // Remove typing and add bot response
                                                adapter.removeTyping();
                                                ChatMessage botMessage = new ChatMessage(ChatMessage.TYPE_BOT, reply);

                                                Log.d("GGG", "Username: " + username + " | Reply: " + reply);

                                                if (reply.trim().toLowerCase().startsWith("available seats")) {
                                                    Intent intent = new Intent(ChatbotActivity.this, SeatSelectionActivity.class);
                                                    intent.putExtra("seatsText", reply);
                                                    seatSelectionLauncher.launch(intent);

                                                } else if (reply.toLowerCase().contains("payment process")) {
                                                    Intent intent = new Intent(ChatbotActivity.this, PaymentActivity.class);
                                                    intent.putExtra("payment", reply);
                                                    paymentLauncher.launch(intent);
                                                } else if(reply.trim().toLowerCase().startsWith("payment successful!") || reply.trim().toLowerCase().startsWith("your booking is")){
                                                    addBookingFromText(username,reply);
                                                    adapter.addMessage(botMessage);
                                                    if (ttsEnabled) {
                                                        textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                                    }
                                                }else if (reply.trim().toLowerCase().matches("booking \\d+ for .*(?:canceled\\.|not found\\.)")) {
                                                    Log.d("CancelFlow", "Reply indicates a cancellation intent");

                                                    // Try to extract booking ID from the text
                                                    Pattern pattern = Pattern.compile("Booking\\s+(\\d+)\\s+for\\s+([\\w.+-]+@[\\w.-]+)\\s+(canceled\\.|not found\\.)", Pattern.CASE_INSENSITIVE);
                                                    Matcher matcher = pattern.matcher(reply);
                                                    if (matcher.find()) {

                                                        String bookingId = matcher.group(1);
                                                        String email = matcher.group(2);

                                                        removeBookingById(email, bookingId);

                                                        Toast.makeText(ChatbotActivity.this, "Booking " + bookingId + " cancelled.", Toast.LENGTH_SHORT).show();
                                                    } else {
                                                        Toast.makeText(ChatbotActivity.this, "Oops, something went wrong your booking is still valib.\n Try again later...", Toast.LENGTH_SHORT).show();
                                                    }

                                                    adapter.addMessage(botMessage);
                                                    if (ttsEnabled) {
                                                        textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                                    }
                                                } else{
                                                    adapter.addMessage(botMessage);
                                                    if (ttsEnabled) {
                                                        textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                                    }
                                                }


                                                // Scroll to the latest message
                                                chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);

                                            } catch (JSONException e) {
                                                handleError("Error parsing response");
                                            }
                                        });
                                    }

                                    @Override
                                    public void onError(String error) {
                                        runOnUiThread(() -> {
                                            handleError("Connection error: " + error);
                                        });
                                    }
                                });
                            }
                        }
                    }
                }
        );



        seatSelectionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            String selectedSeats = data.getStringExtra("selectedSeats");
                            if (selectedSeats != null) {
                                //String message = "You selected the following seats: " + selectedSeats;
                                ChatMessage message = new ChatMessage(ChatMessage.TYPE_USER, selectedSeats);
                                adapter.addMessage(message);

                                client.sendMessage(message.getContent(), new client.NetworkCallback() {
                                    @Override
                                    public void onSuccess(String response) {
                                        runOnUiThread(() -> {

                                            try {
                                                JSONObject json = new JSONObject(response);
                                                String reply = json.getString("reply");

                                                // Remove typing and add bot response
                                                adapter.removeTyping();
                                                ChatMessage botMessage = new ChatMessage(ChatMessage.TYPE_BOT, reply);

                                                if (reply.trim().toLowerCase().startsWith("available seats")) {
                                                    Intent intent = new Intent(ChatbotActivity.this, SeatSelectionActivity.class);
                                                    intent.putExtra("seatsText", reply);  //pass seat data
                                                    seatSelectionLauncher.launch(intent);
                                                    textToSpeech.speak("Select your seats", TextToSpeech.QUEUE_FLUSH, null, null);


                                                }else{
                                                    adapter.addMessage(botMessage);
                                                    if (ttsEnabled) {
                                                        textToSpeech.speak(reply, TextToSpeech.QUEUE_FLUSH, null, null);
                                                    }
                                                }


                                                // Scroll to the latest message
                                                chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);

                                            } catch (JSONException e) {
                                                handleError("Error parsing response");
                                            }
                                        });
                                    }

                                    @Override
                                    public void onError(String error) {
                                        runOnUiThread(() -> {
                                            handleError("Connection error: " + error);
                                        });
                                    }
                                });
                            }
                        }
                    }
                }
        );

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, 1);
        }

        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int langResult = textToSpeech.setLanguage(Locale.US);

                    if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "Language not supported or missing data");
                    }
                } else {
                    Log.e("TTS", "Initialization failed");
                }
            }
        });




        ImageView mic = findViewById(R.id.microphone); // your ImageView
        TextView resultText = findViewById(R.id.messageEditText); // add this TextView to show the result

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    resultText.setText(matches.get(0));
                }
                isListening = false;
            }

            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onError(int error) {
                isListening = false;
                resultText.setText("Error recognizing speech");
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isListening) {
                    speechRecognizer.startListening(speechRecognizerIntent);
                    isListening = true;
                    resultText.setText("Listening...");
                } else {
                    speechRecognizer.stopListening();
                    isListening = false;
                }
            }
        });



    }

    private void addBookingFromText(String userName, String text) {
        try {

            Pattern pattern = Pattern.compile("Booked (\\d+) tickets for (.*?) in (Hall \\d+) at (\\d{2}:\\d{2})\\. Seats: ([A-Za-z0-9, ]+)\\. Booking ID: (\\d+)\\.");

            String[] lines = text.split("\\n");
            Matcher matcher = null;
            boolean found = false;

            for (String line : lines) {
                matcher = pattern.matcher(line);
                if (matcher.find()) {
                    found = true;
                    break;
                }
            }

            if (!found || matcher == null) {
                Log.e("BookingParse", text);
                return;
            }

            int numTickets = Integer.parseInt(matcher.group(1));
            String playName = matcher.group(2);
            String hall = matcher.group(3);
            String showtime = matcher.group(4);
            String seatsStr = matcher.group(5);
            String bookingId = matcher.group(6);

            JSONArray seatsArray = new JSONArray();
            for (String seat : seatsStr.split(",\\s*")) {
                seatsArray.put(seat);
            }

            JSONObject booking = new JSONObject();
            booking.put("hall", hall);
            booking.put("play", playName);
            booking.put("showtime", showtime);
            booking.put("num_tickets", numTickets);
            booking.put("seats", seatsArray);
            booking.put("name", userName);
            booking.put("paid", false);

            Log.d("BookingData", booking.toString());

            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            String jsonStr = prefs.getString(userName, "{}");
            JSONObject userData = new JSONObject(jsonStr);

            JSONObject bookings = userData.has("bookings") ? userData.getJSONObject("bookings") : new JSONObject();
            bookings.put(bookingId, booking);
            userData.put("bookings", bookings);

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(userName, userData.toString());
            editor.apply();

        } catch (Exception e) {
            Log.e("BookingError", "Exception while parsing booking: " + e.getMessage());
            e.printStackTrace();
        }
    }



    private void handleError(String errorMessage) {
        adapter.removeTyping();
        ChatMessage errorChatMessage = new ChatMessage(ChatMessage.TYPE_BOT, errorMessage);
        adapter.addMessage(errorChatMessage);
        chatRecyclerView.scrollToPosition(adapter.getItemCount() - 1);
    }

    private void showHelpDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_help);

        // Optional: make background blur using dialog theme
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.getWindow().setDimAmount(0.7f);  // background dim level

        Button option1 = dialog.findViewById(R.id.option1);
        Button option2 = dialog.findViewById(R.id.option2);
        Button option3 = dialog.findViewById(R.id.option3);

        option1.setOnClickListener(v -> {
            // Handle Option 1
            dialog.dismiss();
        });

        option2.setOnClickListener(v -> {
            // Handle Option 2
            dialog.dismiss();
        });

        option3.setOnClickListener(v -> {
            ttsEnabled = !ttsEnabled;  // Toggle the TTS state

            // Show Toast indicating TTS status
            Toast.makeText(this, ttsEnabled ? "TTS enabled" : "TTS disabled", Toast.LENGTH_SHORT).show();

            // Update button text based on TTS state
            option3.setText(ttsEnabled ? "Stop Spelling" : "Spell Text");

        });

        dialog.show();
    }

    private void removeBookingById(String userName, String bookingId) {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String jsonStr = prefs.getString(userName, "{}");

        try {
            JSONObject userData = new JSONObject(jsonStr);

            if (userData.has("bookings")) {
                JSONObject bookings = userData.getJSONObject("bookings");

                if (bookings.has(bookingId)) {
                    bookings.remove(bookingId);
                    userData.put("bookings", bookings);

                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString(userName, userData.toString());
                    editor.apply();

                    Log.d("BookingRemove", "Booking with ID " + bookingId + " removed.");

                } else {
                    Log.w("BookingRemove", "Booking ID not found: " + bookingId);
                }
            } else {
                Log.w("BookingRemove", "No bookings found for user.");
            }
        } catch (JSONException e) {
            Log.e("BookingRemoveError", "Failed to remove booking: " + e.getMessage());
            e.printStackTrace();
        }
    }

}

// ChatMessage class to represent message data
class ChatMessage {
    public static final int TYPE_USER = 0;
    public static final int TYPE_BOT = 1;
    public static final int TYPE_TYPING = 2;

    private int type;
    private String content;

    public ChatMessage(int type, String content) {
        this.type = type;
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public String getContent() {
        return content;
    }
}

// RecyclerView Adapter
class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<ChatMessage> messages = new ArrayList<>();

    @Override
    public int getItemViewType(int position) {
        return messages.get(position).getType();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == ChatMessage.TYPE_USER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_message, parent, false);
            return new UserMessageViewHolder(view);
        } else if (viewType == ChatMessage.TYPE_BOT) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bot_message, parent, false);
            return new BotMessageViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.typing_indicator, parent, false);
            return new TypingViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ChatMessage message = messages.get(position);
        if (holder instanceof UserMessageViewHolder) {
            ((UserMessageViewHolder) holder).bind(message.getContent());
        } else if (holder instanceof BotMessageViewHolder) {
            ((BotMessageViewHolder) holder).bind(message.getContent());
        } else if (holder instanceof TypingViewHolder) {
            ((TypingViewHolder) holder).startAnimation();
        }
    }

    @Override
    public void onViewRecycled(RecyclerView.ViewHolder holder) {
        if (holder instanceof TypingViewHolder) {
            ((TypingViewHolder) holder).stopAnimation();
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public void addMessage(ChatMessage message) {
        messages.add(message);
        notifyItemInserted(messages.size() - 1);
    }

    public void removeTyping() {
        for (int i = messages.size() - 1; i >= 0; i--) {
            if (messages.get(i).getType() == ChatMessage.TYPE_TYPING) {
                messages.remove(i);
                notifyItemRemoved(i);
                break;
            }
        }
    }
}

// View Holders
class UserMessageViewHolder extends RecyclerView.ViewHolder {
    private TextView textView;

    public UserMessageViewHolder(View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.userMessageTextView);
    }

    public void bind(String message) {
        textView.setText(message);
    }
}

class BotMessageViewHolder extends RecyclerView.ViewHolder {
    private TextView textView;

    public BotMessageViewHolder(View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.botMessageTextView);
    }

    public void bind(String message) {
        textView.setText(message);
    }
}

class TypingViewHolder extends RecyclerView.ViewHolder {
    private TextView textView;
    private Handler handler = new Handler();
    private Runnable runnable;
    private int dotCount = 0;

    public TypingViewHolder(View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.typingTextView);
    }

    public void startAnimation() {
        runnable = new Runnable() {
            @Override
            public void run() {
                dotCount = (dotCount + 1) % 4;
                String dots = "";
                for (int i = 0; i < dotCount; i++) {
                    dots += ".";
                }
                textView.setText(dots);
                handler.postDelayed(this, 500);
            }
        };
        handler.post(runnable);
    }

    public void stopAnimation() {
        handler.removeCallbacks(runnable);
    }
}