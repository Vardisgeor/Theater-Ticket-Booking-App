package com.example.norefunds;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {
    private TextInputLayout tilEmail, tilPassword;
    private EditText etEmail, etPassword;
    private SharedPreferences sharedPreferences;

    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        tilEmail = findViewById(R.id.Name);          // TextInputLayout του email
        tilPassword = findViewById(R.id.etPassword); // TextInputLayout του password

        etEmail = findViewById(R.id.etEmail);         // EditText του email
        etPassword = findViewById(R.id.passwordInput); // EditText του password

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        findViewById(R.id.btnLogin).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.btnSignup).setOnClickListener(v -> attemptSignup());
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showStatus("Please fill all fields");
            return;
        }

        String storedPassword = sharedPreferences.getString("credentials_" +email, "");
        if (storedPassword.equals(password)) {
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("loggedInUserEmail", email);  // Αποθήκευση email χρήστη
            editor.apply();

            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            showStatus("Invalid credentials");
        }
    }

    private void attemptSignup() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showStatus("Please fill all fields");
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showStatus("Please enter a valid email address");
            return;
        }

        if (sharedPreferences.contains(email)) {
            showStatus("User already exists");
        } else {
            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("credentials_" + email, password);
            editor.putString("loggedInUserEmail", email);  // Αποθήκευση email χρήστη
            editor.apply();

            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    private void showStatus(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }
}