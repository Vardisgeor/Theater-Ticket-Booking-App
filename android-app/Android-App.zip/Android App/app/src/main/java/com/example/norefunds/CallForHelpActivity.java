// MyTicketsActivity.java
package com.example.norefunds;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class CallForHelpActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_for_help);
    }
}