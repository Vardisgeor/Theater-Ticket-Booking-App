package com.example.norefunds;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.norefunds.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.FrameLayout;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private FrameLayout btnMyTickets, btnChatbot, btnCallForHelp, btnInfo;

    public JSONObject userData;
    private String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        username = prefs.getString("loggedInUserEmail", "guest");
        Log.d("nameMain", "User name: " + username);

        String jsonStr = prefs.getString( username, "{}");
        try {
            userData = new JSONObject(jsonStr);
        } catch (JSONException e) {
            userData = new JSONObject();
        }
        //addFakeBooking();


        btnMyTickets = findViewById(R.id.btnMyTickets);
        btnChatbot = findViewById(R.id.btnChatbot);
        //btnCallForHelp = findViewById(R.id.btnCallForHelp);
        btnInfo = findViewById(R.id.btnInfo);

        btnMyTickets.setOnClickListener(v -> {
            startActivity(new Intent(this, MyTicketsActivity.class));
        });

        btnChatbot.setOnClickListener(v -> {
            startActivity(new Intent(this, ChatbotActivity.class));
        });



        btnInfo.setOnClickListener(v -> {
            startActivity(new Intent(this, InfoActivity.class));
        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // INFLATE MENU
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void addFakeBooking() {
        try {
            JSONObject userBookings;
            String userKey = "Eleni Markou";  // π.χ. το όνομα χρήστη

            if (userData.has(userKey)) {
                userBookings = userData.getJSONObject(userKey);
            } else {
                userBookings = new JSONObject();
                userData.put(userKey, userBookings);
            }

            JSONObject booking1 = new JSONObject();
            booking1.put("hall", "Hall 1");
            booking1.put("showtime", "18:00");
            booking1.put("num_tickets", 2);

            JSONArray seatsArray = new JSONArray();
            seatsArray.put("A1");
            seatsArray.put("A2");
            booking1.put("seats", seatsArray);

            booking1.put("name", "Eleni Markou");
            booking1.put("phone", "11");
            booking1.put("email", "eleni.markou@example.com");
            booking1.put("paid", false);

            userBookings.put("1", booking1);

            SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("userData_" + username, userData.toString());
            editor.apply();

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}